<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
/**
 *
 * @package   Codestar Framework - WordPress Options Framework
 * @author    Codestar <info@codestarthemes.com>
 * @link      http://codestarframework.com
 * @copyright 2015-2022 Codestar
 *
 *
 * Plugin Name: Shinonomeiro_CSF
 * Plugin URI: https://github.com/Fuukei/Shinonomeiro_CSF
 * Author: Codestar with Fuukei
 * Author URI: https://github.com/Fuukei
 * Version: 2.3.0e
 * Description: A Simple and Lightweight WordPress Option Framework for Shinonomeiro
 * Text Domain: sakurairo_csf
 * Domain Path: /languages
 *
 */
require_once plugin_dir_path( __FILE__ ) .'classes/setup.class.php';
require_once plugin_dir_path(__FILE__) .'options/theme-options.php';
